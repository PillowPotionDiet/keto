
<!DOCTYPE html>
<html lang="en">
   <head>
      <script>
	var protocol = ((document.location.protocol=='https:')?'https://':'http://');
	var uri = encodeURIComponent(window.location.hostname+window.location.pathname+window.location.search);
	document.write('<s' + 'cript src="' + protocol + 'main.tgoptimize.com/load.js?r='+Math.random()+((typeof tg_opt_verifier !== 'undefined')?'&v='+tg_opt_verifier:'')+'&u='+uri+'" type="text/javascript">' + '<\/s' + 'cript>');
</script>
      
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KMZ74FC');</script>
<!-- End Google Tag Manager -->

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-169212633-21"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-169212633-21');
  gtag('config', 'G-SNNMPY2Z6B');
</script>

  
  
<script>
  </script>


<!-- jQuery 1.7.2+ or Zepto.js 1.0+ -->
<script src="https://cdn.truegcloud.com/scripts/jquery.1.9.1.min.js"></script>

<!-- Start Visual Website Optimizer Synchronous Code -->
<script type='text/javascript'>
    var _vis_opt_account_id = 407590;
    var _vis_opt_protocol = (('https:' == document.location.protocol) ? 'https://' : 'http://');
    document.write('<s' + 'cript src="' + _vis_opt_protocol +
        'dev.visualwebsiteoptimizer.com/deploy/js_visitor_settings.php?v=1&a=' + _vis_opt_account_id + '&url=' + encodeURIComponent(document.URL) + '&random=' + Math.random() + '" type="text/javascript">' + '<\/s' + 'cript>');
</script>

<script type='text/javascript'>
    if (typeof(_vis_opt_settings_loaded) == "boolean") {
        document.write('<s' + 'cript src="' + _vis_opt_protocol +
            'd5phz18u4wuww.cloudfront.net/vis_opt.js" type="text/javascript">' + '<\/s' + 'cript>');
    }
    // if your site already has jQuery 1.4.2, replace vis_opt.js with vis_opt_no_jquery.js above
</script>

<script type='text/javascript'>
    if (typeof(_vis_opt_settings_loaded) == "boolean" && typeof(_vis_opt_top_initialize) == "function") {
        _vis_opt_top_initialize();
        vwo_$(document).ready(function() {
            _vis_opt_bottom_initialize();
        });
    }
</script>
<!-- End Visual Website Optimizer Synchronous Code -->

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2252938071610789');  
  fbq('init', '');
  fbq('track', 'PageView');
  fbq('track', 'ViewContent');
  setTimeout(function(){
  fbq("track",'20Min');
  }, 1200000);
  setTimeout(function(){
  fbq("track",'10Min');
  }, 600000);
  setTimeout(function(){
  fbq("track",'25Min');
  }, 1500000);
  setTimeout(function(){
  fbq("track",'30Min');
  }, 1800000);
</script>
<noscript>
  <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2252938071610789&ev=PageView&noscript=1" />
  <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1" />
</noscript>
<!-- End Facebook Pixel Code -->

<script type="text/javascript">
    function hideGreyHead() {
      document.getElementById("greyhead").style.display = "none";
    }
	function showBuyLink() {
	  document.getElementById("buylink").style.display = "block";
	}
        // adjust this as needed, 1 sec = 1000
    setTimeout("hideGreyHead()", 15000);
	setTimeout("showBuyLink()", 5000);
</script>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<meta name="robots" content="noindex">

<title>Simple Promise&#8482;</title>

<link href="../css/skeleton.min.css" rel="stylesheet">
<link href="../css/all.min.css" rel="stylesheet">
<link href="../css/main.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i|Montserrat:400,400i,600,600i,700,700i,800,800i&display=swap" rel="stylesheet">

<!-- Header Logo -->
<nav class="fixed-top">
	<img src="https://cdn.truegcloud.com/simplepromise/SP-Logo-Hanging.png" alt="" class="d-none d-md-block">
</nav>

<!-- Call Reveal -->
<div id="menu-bar">
	<div class="handle">
		<img src="https://cdn.truegcloud.com/cyabags/5thglow-phone-inverted.svg" alt="" width="25" height="25">
	</div>
	<h6>
		1-800-259-9522<br/>
		<small><i class="fas fa-chevron-left"></i> Press <kbd>ESC</kbd> to close</small>
	  </h6>
</div>

<script type='text/javascript'>
window.__lo_site_id = 329229;

	(function() {
		var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
		wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
	  })();
	</script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Xitox</title>
      <link href="https://cdn.truegcloud.com/Xitox/DTC/favicon.png" rel="shortcut icon" type="image/x-icon">
      <link href="../css/DTC-css.css" rel="stylesheet">
      <link rel="stylesheet" href="../css/DTC-slick.css">
      <link rel="stylesheet" href="../css/DTC-slick-theme.css">
      <link rel="stylesheet" href="../css/DTC-animation.css">
      <link rel="stylesheet" href="../css/DTC-style.css">
      <link rel="stylesheet" href="../css/dtc-style-new.css">
      <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i|Montserrat:400,400i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
      
      <style>
         .spec {
            background: none;
         }
         .rescue .product-img {
            max-width: 350px;
         }
         @media (min-width: 1200px) {
            .spec {
               background: url(https://cdn.truegcloud.com/levitox/DTC/spec-bg2.png) no-repeat center;"
            }
         }
      </style>
      <script type="text/javascript">
         (function(c,l,a,r,i,t,y){
            c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
            t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
            y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
         })(window, document, "clarity", "script", "sx4twlt4x3");
      </script>
   </head>

   <body>
      <div class="wrap">
         <header class="order order-drop">
            <div class="container">
               <h1 class="order-title lt0 mx-auto">Supporting Your Body's Natural Ability <br class="d-none d-lg-block">To Remove Unwanted Guests</h1>
               <div class="order-content">
                  <div class="order-lists">
                     <ul class="order-list">
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-1.png"> 
                           <p class="orderList-text lt1 mb-0"> 
                              <span class="orderList-text_yellow">Supports</span> the body's defenses against various types of parasites</p>
                        </li>
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-2.png"> 
                           <p class="orderList-text lt2 mb-0"> 
                              <span class="orderList-text_yellow">Removes</span> their waste products</p>
                        </li>
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-3.png"> 
                           <p class="orderList-text lt3 mb-0"> 
                              <span class="orderList-text_yellow">Normalizes</span> metabolic processes</p>
                        </li>
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-4.png"> 
                           <p class="orderList-text lt4 mb-0"> 
                              <span class="orderList-text_yellow">Strengthens</span> the body's protective functions
                           </p>
                        </li>
                     </ul>
                     <div class="orderLeft-footer py-2"> 
                        <span class="orderLeftFooter-text">
                        &#8226; Backed by extensive research</span>
                        <span class="orderLeftFooter-text">
                        &#8226; 100% effective</span>
                        <span class="orderLeftFooter-text">
                        &#8226; The best formula available today</span> 
                     </div>
                  </div>
            
                  <section id="" class="py-2">  
                     <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
        <th scope="col">
            <form class="fade-box" action="/go/order-fe-purchase.php" method="get" id="form_cta1">
                <input type="hidden" name="pid" value="XITOX1-AL-19B">
            </form>
        </th>

        <th scope="col">
            <form class="fade-box" action="/go/order-fe-purchase.php" method="get" id="form_cta2">
                <input type="hidden" name="pid" value="XITOX6-AL-19B">
            </form>
        </th>

        <th scope="col">
            <form class="fade-box" action="/go/order-fe-purchase.php" method="get" id="form_cta3">
                <input type="hidden" name="pid" value="XITOX3-AL-19B">
            </form>
        </th>
    </tr>
</table>

<div class="row-new justify-content-center fade-container fe-atc-zindex">
	<div class="col-11 col-md-4 text-center py-0 px-md-1 px-lg-2  mb-md-0 mb-2">
		<div onclick="javascript:submitform('form_cta1');" class="atc-transform" style="cursor:pointer;">
			<img class="img-fluid shipping-ribbon d-md-none" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-shippingribbon.png" alt="">
			<div class="text-right text-md-left div-82">
				<p class="text-blue atc-tab new-size">SAMPLER PACKAGE</p>
			</div>
			
			<div class="atc">
				<div class="atc-section position-relative" id="atc-left">
					<h4 class="text-white d-none d-md-block">1-MONTH SUPPLY</h4>

					<div class="atc-savings">
						<p>SAVE <br>$30</p>
					</div>

					<img class="atc-guarantee img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-guarantee.png" alt="">
					<img class="atc-img img-fluid" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-1.png" alt="">
				</div>

				<div class="atc-section" id="atc-right">
					<h6 class="text-white d-md-none mb-0" style="font-weight: 600;">1-MONTH SUPPLY</h6>
					<h1 class="atc-price mr-1 mb-0 mb-md-2"><span class="atc-dollar">$</span>59</h1><h5 class="mb-0 mb-md-2"> /EACH</h5>
					<p class="atc-whitetext d-none d-md-block">FAST & FREE SHIPPING</p>
					<p class="atc-yellowtext d-md-none">YOU SAVE $30</p>
					<p class="atc-whitetext mb-1 mb-md-3">365-DAY MONEY-BACK GUARANTEE</p>

					<div class="atc-button  mx-auto text-center">
						<h2 style="animation: none; opacity: 1; visibility: visible; transform: none;">DETOX NOW</h2><img class="img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-icon.svg" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-11 col-md-4 text-center py-0 px-md-1 px-lg-2  mb-md-0 mb-2">
		<div onclick="javascript:submitform('form_cta2');" class="atc-transform" style="cursor:pointer;">
			<img class="img-fluid shipping-ribbon d-md-none" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-shippingribbon.png" alt="">
			<div class="text-right text-md-left  div-61">
				<p class="text-blue atc-tab new-size">BEST SELLER!</p>
			</div>
			
			<div class="atc center">
				<div class="atc-section position-relative" id="atc-left">
					<h4 class="text-white d-none d-md-block">6-MONTH SUPPLY</h4>

					<div class="atc-savings">
						<p>SAVE <br>$336</p>
					</div>

					<img class="atc-guarantee img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-guarantee.png" alt="">
					<img class="atc-img img-fluid" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-6.png" alt="">
				</div>

				<div class="atc-section" id="atc-right">
					<h6 class="text-white d-md-none mb-0" style="font-weight: 600;">6-MONTH SUPPLY</h6>
					<h1 class="atc-price mr-1 mb-0 mb-md-2"><span class="atc-dollar">$</span>33</h1><h5 class="mb-0 mb-md-2"> /EACH</h5>
					<p class="atc-whitetext d-none d-md-block">FAST & FREE SHIPPING</p>
					<p class="atc-yellowtext d-md-none">YOU SAVE $336</p>
					<p class="atc-whitetext mb-1 mb-md-3">365-DAY MONEY-BACK GUARANTEE</p>

					<div class="atc-button  mx-auto text-center">
						<h2 style="animation: none; opacity: 1; visibility: visible; transform: none;">DETOX NOW</h2><img class="img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-icon.svg" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-11 col-md-4 text-center py-0 px-md-1 px-lg-2">
		<div onclick="javascript:submitform('form_cta3');" class="atc-transform" style="cursor:pointer;">
			<img class="img-fluid shipping-ribbon d-md-none" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-shippingribbon.png" alt="">
			<div class="text-right text-md-left  div-71">
				<p class="text-blue atc-tab new-size">MOST POPULAR!</p>
			</div>
			
			<div class="atc">
				<div class="atc-section position-relative" id="atc-left">
					<h4 class="text-white d-none d-md-block">3-MONTH SUPPLY</h4>

					<div class="atc-savings">
						<p>SAVE <br>$120</p>
					</div>

					<img class="atc-guarantee img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-guarantee.png" alt="">
					<img class="atc-img img-fluid" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-3%20%28v3%29.png" alt="">
				</div>

				<div class="atc-section" id="atc-right">
					<h6 class="text-white d-md-none mb-0" style="font-weight: 600;">4-MONTH SUPPLY</h6>
					<h1 class="atc-price mr-1 mb-0 mb-md-2"><span class="atc-dollar">$</span>49</h1><h5 class="mb-0 mb-md-2"> /EACH</h5>
					<p class="atc-whitetext d-none d-md-block">FAST & FREE SHIPPING</p>
					<p class="atc-yellowtext d-md-none">YOU SAVE $</p>
					<p class="atc-whitetext mb-1 mb-md-3">365-DAY MONEY-BACK GUARANTEE</p>

					<div class="atc-button mx-auto text-center">
						<h2 style="animation: none; opacity: 1; visibility: visible; transform: none;">DETOX NOW</h2><img class="img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-icon.svg" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--<div class="row mbg-banner">
	<div class="col-lg-11 mx-auto">
		<img src="https://cdn.truegcloud.com/citroburn/images/MBG-Desktop.png" alt="" class="img-fluid my-2 d-none d-sm-block mx-auto">
		<center><img src="https://cdn.truegcloud.com/citroburn/images/MBG-Desktop.png" alt="" class="img-fluid my-2 d-block d-sm-none"></center>
	</div>
</div>-->

<script type="text/javascript">
	function submitform(formid) {
		window.onbeforeunload = function() {};
		//$('#' + formid).submit();
		document.getElementById(formid).submit();
	}
</script>

<style>
	.atc p, .atc-tab {
	font-family: 'montserrat';
}

.atc-tab {
	display: inline-block;
    background: #fbc630;
    padding: 11px 23px;
    border-radius: 15px 15px 0 0;
    font-weight: bold;
	margin: 0;
	line-height: 1;
}

.atc {
	background: url('https://cdn.truegcloud.com/xanoburn/images/atc/atc-bg.jpg');
	background-size: cover;
	background-position: center;
	padding: 25px 15px;
	position: relative;
	border: 4px solid transparent;
	display: flex;
	flex-direction: column;
}

.atc.center {
	border: 4px solid #fbc630;
	border-radius: 0px 4px 4px 4px;
}

.atc-img {
	max-height: 250px;
}

.atc-savings {
	background: #f3bc00;
    display: flex;
	align-items: center;
	justify-content: center;
    position: absolute;
    padding: 10px;
    border-radius: 50%;
    width: 100px;
    height: 100px;

	top: 25%;
    left: 95%;
    transform: translate(-95%, -25%) rotate(15deg);
}

.atc-guarantee {
	display: none;
	position: absolute;
	width: 50px;
    top: 95%;
    left: 90%;
    transform: translate(-90%, -95%);
}

.atc-savings p {
	font-weight: 800;
    font-size: 29px;
    line-height: 1em;
    color: #0a3b6c;
	margin: 0;
}

.atc-dollar {
    font-size: 30px;
    vertical-align: top;
    top: 12px;
    position: relative;
	margin-right: 3px;
}

.atc h5 {
	color: white;
    font-weight: bold;
    display: inline-block;
    letter-spacing: 1px;
}

.atc-whitetext {
	font-weight: bold;
    color: white;
    letter-spacing: -0.5px;
    font-size: 16px;
    font-family: 'Roboto', 'Helvetica' !important;
	margin: 0;
	line-height: 1.3;
}

.atc-yellowtext {
	font-weight: 900;
    color: #edba14;
    font-size: 12px;
    margin-bottom: 2px;
}

.atc-price {
	display: inline-block;
    font-size: 77px;
    color: #edba14;
}

.atc-button {
	background: #f3bc00;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px 0;
    margin: 0 8px;
}

.atc-button h2 {
	font-size: 19px;
    font-weight: 700;
    letter-spacing: 1px;
    margin: 0;
	padding-right: 10px;
	max-width: 90%;
    display: inline-block;
}

.atc-button img {
	max-width: 24px !important;
}

.desktop-width {
	margin-right: -50px !important; 
	margin-left: -50px !important;
}

/* Disable any scroll-triggered animations within the CTA button only */
.fe-atc-zindex .atc-button,
.fe-atc-zindex .atc-button * {
	animation: none !important;
	opacity: 1 !important;
	visibility: visible !important;
}

@media (max-width: 992px) {
	.atc-tab {
		padding: 8px 14px;
		font-size: 16px;
	}
	.atc-dollar {
		font-size: 20px;
		top: 7px;
	}
}

/*IPAD ONLY*/
@media (min-width: 768px) and (max-width: 992px) {
	.atc {
		padding: 15px 5px;
	}

	.atc-img {
		max-height: 200px;
	}

	.atc-savings {
		width: 80px;
		height: 80px;
	}

	.atc-savings p {
		font-size: 22px;
	}

	.atc-price {
		font-size: 45px;
	}

	.atc h5 {
		font-size: 15px;
	}

	.atc-whitetext {
		font-size: 12px;
	}

	.atc-button {
		padding: 10px 0;
	}

	.atc-button h2 {
		font-size: 15px;
	}
}

/*IPHONE ONLY*/
@media (max-width: 767px) {
	.atc {
		border: 2px solid #fbc630 !important;
		flex-direction: row;
		padding: 10px 5px;

		background-color: #153d65;
		background-position: 0px;
		background-size: 45%;
		background-repeat: no-repeat;
	}

	.atc-section {
		width: 50%;
		position: relative;
	}

	.atc-tab {
		padding: 5px 14px;
		font-size: 11px;
		border-radius: 8px 8px 0 0;
	}
	
	.atc-savings {
		display: none;
	}

	.atc-guarantee {
		display: block;
	}

	.atc-dollar {
		font-size: 17px;
		bottom: 16px;
    	margin-right: 2px;
		position: relative;
	}

	.atc h5 {
		font-size: 13px;
	}

	.atc-price {
		font-size: 40px;
	}

	.atc-button h2 {
		font-size: 12px;
		letter-spacing: 0;
	}

	.atc-button img {
		max-width: 15px !important;
	}

	.atc-button {
		padding: 10px 0;
		width: 80%;
    	margin: auto;
	}

	.atc-whitetext {
		font-size: 8.5px;
	}

	#atc-left {
		width: 45%;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	#atc-right {
		width: 55%;
		border-left: 2px solid;
   	 	border-image: linear-gradient( to top, transparent, #ffffff3d, transparent ) 1 100%;
	}

	.atc-img {
		max-height: 150px;
	}

	.shipping-ribbon {
		position: absolute;
		z-index: 2;
		width: 25%;
		left: -5%;
		top: 16%;
		transform: translate(5%, -16%);
	}
}
</style>  
                  </section>

               </div>
            </div>
         </header>

         <section class="pest">
            <div class="container">
               <h2 class="pest-title lt17">
                  Parasites are the scourge of the 21st century
               </h2>
               <span class="pest-subTitle lt18">
               Admit it, it seems like anyone can get infected, except you? Check if you have the main symptoms of infection:
               </span> 
               <div class="pest-blocks">
                  <div class="row justify">
                     <div class="pest-item pest-item_first pest-item-1">
                        <p class="pest-text lt19">
                           Bad breath, plague on the tongue
                        </p>
                     </div>
                     <div class="pest-item pest-item_middle pest-item-2">
                        <p class="pest-text lt20">
                           Digestive problems (diarrhea, constipation, diarrhea)
                        </p>
                     </div>
                     <div class="pest-item pest-item-3">
                        <p class="pest-text lt21">
                           Quick fatigue, constant tiredness
                        </p>
                     </div>
                  </div>
                  <div class="row">
                     <div class="pest-item pest-item-4">
                        <p class="pest-text lt22">
                           Abundance of papillomas and moles
                        </p>
                     </div>
                     <div class="pest-item pest-item_middle pest-item-5">
                        <p class="pest-text lt23">
                           Dermatitis, eczema, rash
                        </p>
                     </div>
                     <div class="pest-item pest-item_last pest-item-6">
                        <p class="pest-text lt24">
                           Irritability, nervousness, poor sleep
                        </p>
                     </div>
                  </div>
               </div>
               <div class="notice notice_border">
                  <div class="notice_bg-white">
                     <p class="notice-text lt25"> 
                        <span class="notice-text_red">Timely body recovery methods are the key to good health.</span> If you find any of these signs, take action as soon as possible.
                     </p>
                  </div>
               </div>
            </div>
         </section>

         <section class="everywhere">
            <div class="container">
               <h2 class="everywhere-title lt26">
                  THEY LIVE EVERYWHERE
               </h2>
               <p class="everywhere-text lt27">
                  Thorough hygiene, meticulous food preparation, and even avoiding trips to tourist countries <span class="everywhere-text_orange">do not guarantee you complete protection from parasite infestation.</span>
               </p>
            </div>
         </section>

         <section class="every2">
            <div class="container">
               <h2 class="every2-title lt28">
                  You can get infected<br class="d-none d-lg-block"> even in your own home.
               </h2>
               <div class="every2-block">
                  <div class="every2Block-item every2Block-item1">
                     <h3 class="every2Item-title lt29">
                        Bathroom
                     </h3>
                     <p class="every2Item-text lt30">
                        The dirtiest place in the house. You wash your hands there after being outside, you rinse dust and dirt off your body there - along with parasite particles. 78% of them are not destroyed by soap.
                     </p>
                  </div>
                  <div class="every2Block-item every2Block-item2">
                     <h3 class="every2Item-title lt31">
                        Hallway
                     </h3>
                     <p class="every2Item-text lt32">
                        We bring microscopic helminth larvae home on the soles of our shoes. We place our shoes on the shelf and walk where the parasites might just have stayed.
                     </p>
                  </div>
                  <div class="every2Block-item every2Block-item3">
                     <h3 class="every2Item-title lt33">
                        Kitchen
                     </h3>
                     <p class="every2Item-text lt34">
                        While washing meat, vegetables, and fruits in the sink, invisible killers spread with them in the spray. Only chlorine, which is not compatible with food, can instantly kill them.
                     </p>
                  </div>
                  <div class="every2Block-item every2Block-item4">
                     <h3 class="every2Item-title lt35">
                        Public transport
                     </h3>
                     <p class="every2Item-text lt36">
                        You never know how many people have held the same handrail before you. Along with fingerprints, worm eggs are often left on them.
                     </p>
                  </div>
                  <div class="every2Block-item every2Block-item5">
                     <h3 class="every2Item-title lt37">
                        Cafés, restaurants, "street" food
                     </h3>
                     <p class="every2Item-text lt38">
                        The quality of cooked food outside the home cannot be monitored. Sanitary standards must be observed everywhere, but it is impossible to control them.
                     </p>
                  </div>
                  <div class="every2Block-item every2Block-item6">
                     <h3 class="every2Item-title lt39">
                        Pets
                     </h3>
                     <p class="every2Item-text lt40">
                        Pets carry over a million eggs and cysts in and on their bodies. Poor hygiene can often lead to serious diseases in humans.
                     </p>
                  </div>
               </div>
            </div>
         </section>

         <section class="rescue">
            <div class="container">
               <h2 class="rescue-title lt41">
                  DO NOT DESPAIR. <span class="rescue-title_big">THERE IS A SOLUTION.</span>
               </h2>
               <div class="rescue-mobile">
                  <div class="rescue-blockImg"><img alt="" class="rescue-people" src="https://cdn.truegcloud.com/levitox/DTC/people.png"></div>
                  <div class="product-img"><img alt="" class="rescue-product" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-1%20%28with%20pads%29.png"></div>
               </div>
               <div class="product-img"><img alt="" class="rescue-product" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-1%20%28with%20pads%29.png"></div>
               <div class="rescue-block">
                  <p class="rescue-text rescue-text_big lt42">
                     Xitox combines potent herbal extracts known to negatively affect the vital activity of harmful organisms.</p>
                  <p class="rescue-text lt43">
                     Xitox is designed to support the natural processes of urination, bile secretion, and digestion, which may assist in general wellness.Xitox includes ingredients with a gentle laxative effect that may aid in the detoxification process, helping to cleanse the body.
                  </p>
                  <a href="#order_form" class="orderForm-btn lt44">
                  ORDER
                  </a> 
               </div>
            </div>
         </section>

         <section class="effect">
            <div class="container">
               <h2 class="effect-title lt58">
                  Xitox effectivenes is back by extensive research
               </h2>
               <p class="effect-text lt59">
                  Studies have indicated that participants experienced various health benefits while using Xitox. It's formulated to support a healthy lifestyle. <span class="effect-text_bold">Xitox is well-regarded by experts for its formulation based on natural ingredients known to support liver health and keeping harmful organisms out.</span>
               </p>
               <div class="effect-block">
                  <div class="effect-item">
                     <div class="scale">
                        <div class="scale-bg scale_yellow"></div>
                        <span class="scale-text lt60">97%</span> 
                     </div>
                     <p class="effectItem-text lt61">
                        97% of participants noted a significant improvement in well-being, normalization of sleep, and stable stool
                     </p>
                  </div>
                  <div class="effect-item">
                     <div class="scale">
                        <div class="scale-bg scale_pink"></div>
                        <span class="scale-text lt62">74%</span> 
                     </div>
                     <p class="effectItem-text lt63">
                        74% of users reported noticeable improvements in the appearance of their skin, including reductions in papillomas
                     </p>
                  </div>
                  <div class="effect-item">
                     <div class="scale">
                        <div class="scale-bg scale_red"></div>
                        <span class="scale-text lt64">82%</span> 
                     </div>
                     <p class="effectItem-text lt65">
                        82% of users experienced significant relief from a variety of skin issues
                     </p>
                  </div>
                  <div class="effect-item">
                     <div class="scale">
                        <div class="scale-bg scale_lightPink"></div>
                        <span class="scale-text lt66">100%</span> 
                     </div>
                     <p class="effectItem-text lt67">
                        In our studies, participants achieved a 100% success rate in improving test results related to general body health
                     </p>
                  </div>
               </div>
            </div>
         </section>

         <section class="spec">
            <div class="container">
               <div class="spec-block">
                  <h2 class="spec-title lt68">
                     <img alt="" class="doctor-mobile" src="https://cdn.truegcloud.com/levitox/DTC/doctor-mobile2.png">
                     Expert comment
                  </h2>
                  <p class="spec-text spec-text_big lt69">
                     Parasitic infections are the scourge of the 21st century. Harmful microorganisms have adapted to survive in any conditions. They are quite
                     difficult to recognize in analyses, and the symptoms of infection are similar to other diseases. The worst part is that for years
                     you can treat a disease that will recur or even die: treat it and not know the root cause is parasites.
                  </p>
                  <p class="spec-text lt70">
                     That is why prevention is the best measure for controlling pests. When choosing a product for removing parasitic infections and for prevention, I advise you to pay attention to the natural composition of herbal ingredients.
                  </p>
                  <p class="spec-text lt71">
                     Xitox stands out in this regard. It is crafted from a blend of herbal ingredients known for their safety and efficacy. It's a choice worth considering for anyone proactive about their health, especially when concerns about microorganisms arise. Early attention to potential health issues can significantly reduce the risk of serious complications.
                  </p>
                  <div class="spec-footer">
                     <span class="spec-name lt72">John Doe</span>
                     <span class="spec-prof lt73">Head Researcher of Harmful Organisms</span>
                     <img alt="" class="spec-sign" src="https://cdn.truegcloud.com/levitox/DTC/sign.png">
                  </div>
               </div>
            </div>
         </section>

         <section class="comment">
            <div class="container">
               <h2 class="comment-title lt74">
                  Reviews
               </h2>
               <div class="slider">
                  <div class="slider-item">
                     <img src="https://cdn.truegcloud.com/levitox/DTC/slider-1.png" alt="" class="slider-avatar"> 
                     <p class="slider-info lt75"> <span class="slider-name">Daniel James</span>, <span class="slider-age">43 years old</span> 
                     </p>
                     <p class="slider-text lt76">
                        I neglected hygiene my entire life and knew no trouble until some parasites entered my body. For three months, I was nauseous, suffered from stomach issues, alternating between constipation and diarrhea. Additionally, constant weakness and disturbed sleep. I went to the doctor, took some pills - it helped for a month. Then it all started over again. A doctor I knew recommended the Xitox course. Within the first few days, my stool normalized, and my stomach pains became rare. After the course, I felt like I was born anew! Passed tests just in case - my body is clean.
                     </p>
                     <img src="https://cdn.truegcloud.com/levitox/DTC/stars.png" alt="" class="stars"> 
                  </div>
                  <div class="slider-item">
                     <img src="https://cdn.truegcloud.com/levitox/DTC/slider-2.png" alt="" class="slider-avatar"> 
                     <p class="slider-info lt77"> <span class="slider-name">Sarah Green</span>, <span class="slider-age">37 years old</span> 
                     </p>
                     <p class="slider-text lt78">
                        Two months ago, I started feeling extremely tired. By the end of the day, I was nearly exhausted. I thought it was due to stress or nerves, but it turned out I had worms. I couldn't even imagine having them. The doctor prescribed Xitox. Two weeks later, I felt much better: became more alert, my sleep improved. By the end of the course, I noticed my skin became clearer and my sleep improved. My relatives also noticed positive changes, and most importantly, my tests are now clean. I'm happy it all turned out so well!
                     </p>
                     <img src="https://cdn.truegcloud.com/levitox/DTC/stars.png" alt="" class="stars"> 
                  </div>
                  <div class="slider-item">
                     <img src="https://cdn.truegcloud.com/levitox/DTC/slider-3.png" alt="" class="slider-avatar"> 
                     <p class="slider-info lt79"> <span class="slider-name">Emily Smith</span>, <span class="slider-age">39 years old</span> 
                     </p>
                     <p class="slider-text lt80">
                        As it turned out, parasites can cause quite serious illnesses. Recently, I was diagnosed with pyelonephritis. Initially treated with one preparation, then prescribed another complex. But it temporarily eased the symptoms, and then they returned: fever, nausea, persistent headache, swelling, and pale skin. Doctors shrugged their shoulders, so I went to a private clinic. I was told it was due to parasites and needed urgent elimination. They advised me to start using Xitox, after which I quickly recovered! Everyone should buy it for prevention.
                     </p>
                     <img src="https://cdn.truegcloud.com/levitox/DTC/stars.png" alt="" class="stars"> 
                  </div>
                  <div class="slider-item">
                     <img src="https://cdn.truegcloud.com/levitox/DTC/slider-4.png" alt="" class="slider-avatar"> 
                     <p class="slider-info lt81"> <span class="slider-name">Michael Johnson</span>, <span class="slider-age">45 years old</span> 
                     </p>
                     <p class="slider-text lt82">
                        A 45-year-old man suffered from persistent angina pectoris for the past two years. I learned that it is scientifically called tonsillitis. Cases like mine are considered chronic. Changed several doctors and many, many treatment regimens. You know, with the frequent use of antibiotics, I felt really bad. Add stomatitis. Then I was lucky enough to visit a normal doctor who saw the presence of a parasitic infestation and recommended Xitox. It helped me; I haven't been sick since. I use it once a year for prophylaxis.
                     </p>
                     <img src="https://cdn.truegcloud.com/levitox/DTC/stars.png" alt="" class="stars"> 
                  </div>
               </div>
               <div class="alarm">
                  <div class="alarm-left">
                     <h3 class="alarm-title lt83">
                        PLEASE, TAKE NOTICE!
                     </h3>
                  </div>
                  <div class="alarm-right lt84">
                     The number of Xitox packages needed for the desired result, <span class="alarm-bold">determined individually and in some cases may be increased.</span>
                  </div>
               </div>
            </div>
         </section>

         <section class="foot order pb-5">
            <div class="container">
               <h1 class="order-title lt0 mx-auto">
                  Supporting Your Body's Natural Ability <br class="d-none d-lg-block">To Remove Unwanted Guests
               </h1>
               <div class="order-content">
                  <div class="order-lists">
                     <ul class="order-list">
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-1.png"> 
                           <p class="orderList-text lt1 mb-0"> 
                              <span class="orderList-text_yellow">Supports</span> the body's defenses against various types of parasites</p>
                        </li>
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-2.png"> 
                           <p class="orderList-text lt2 mb-0"> 
                              <span class="orderList-text_yellow">Removes</span> their waste products</p>
                        </li>
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-3.png"> 
                           <p class="orderList-text lt3 mb-0"> 
                              <span class="orderList-text_yellow">Normalizes</span> metabolic processes</p>
                        </li>
                        <li class="orderList-item">
                           <img alt="" class="orderList-img" src="https://cdn.truegcloud.com/Xitox/DTC/orderList-4.png"> 
                           <p class="orderList-text lt4 mb-0"> 
                              <span class="orderList-text_yellow">Strengthens</span> the body's protective functions
                           </p>
                        </li>
                     </ul>
                     <div class="orderLeft-footer py-2"> 
                        <span class="orderLeftFooter-text">
                        &#8226; Backed by extensive research</span>
                        <span class="orderLeftFooter-text">
                        &#8226; 100% effective</span>
                        <span class="orderLeftFooter-text">
                        &#8226; The best formula available today</span> 
                     </div>
                  </div>
              
                  <section id="" class="py-2">  
                     <div id="order_form">
                     <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
        <th scope="col">
            <form class="fade-box" action="/go/order-fe-purchase.php" method="get" id="form_cta1">
                <input type="hidden" name="pid" value="XITOX1-AL-19B">
            </form>
        </th>

        <th scope="col">
            <form class="fade-box" action="/go/order-fe-purchase.php" method="get" id="form_cta2">
                <input type="hidden" name="pid" value="XITOX6-AL-19B">
            </form>
        </th>

        <th scope="col">
            <form class="fade-box" action="/go/order-fe-purchase.php" method="get" id="form_cta3">
                <input type="hidden" name="pid" value="XITOX3-AL-19B">
            </form>
        </th>
    </tr>
</table>

<div class="row-new justify-content-center fade-container fe-atc-zindex">
	<div class="col-11 col-md-4 text-center py-0 px-md-1 px-lg-2  mb-md-0 mb-2">
		<div onclick="javascript:submitform('form_cta1');" class="atc-transform" style="cursor:pointer;">
			<img class="img-fluid shipping-ribbon d-md-none" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-shippingribbon.png" alt="">
			<div class="text-right text-md-left div-82">
				<p class="text-blue atc-tab new-size">SAMPLER PACKAGE</p>
			</div>
			
			<div class="atc">
				<div class="atc-section position-relative" id="atc-left">
					<h4 class="text-white d-none d-md-block">1-MONTH SUPPLY</h4>

					<div class="atc-savings">
						<p>SAVE <br>$30</p>
					</div>

					<img class="atc-guarantee img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-guarantee.png" alt="">
					<img class="atc-img img-fluid" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-1.png" alt="">
				</div>

				<div class="atc-section" id="atc-right">
					<h6 class="text-white d-md-none mb-0" style="font-weight: 600;">1-MONTH SUPPLY</h6>
					<h1 class="atc-price mr-1 mb-0 mb-md-2"><span class="atc-dollar">$</span>59</h1><h5 class="mb-0 mb-md-2"> /EACH</h5>
					<p class="atc-whitetext d-none d-md-block">FAST & FREE SHIPPING</p>
					<p class="atc-yellowtext d-md-none">YOU SAVE $30</p>
					<p class="atc-whitetext mb-1 mb-md-3">365-DAY MONEY-BACK GUARANTEE</p>

					<div class="atc-button  mx-auto text-center">
						<h2 style="animation: none; opacity: 1; visibility: visible; transform: none;">DETOX NOW</h2><img class="img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-icon.svg" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-11 col-md-4 text-center py-0 px-md-1 px-lg-2  mb-md-0 mb-2">
		<div onclick="javascript:submitform('form_cta2');" class="atc-transform" style="cursor:pointer;">
			<img class="img-fluid shipping-ribbon d-md-none" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-shippingribbon.png" alt="">
			<div class="text-right text-md-left  div-61">
				<p class="text-blue atc-tab new-size">BEST SELLER!</p>
			</div>
			
			<div class="atc center">
				<div class="atc-section position-relative" id="atc-left">
					<h4 class="text-white d-none d-md-block">6-MONTH SUPPLY</h4>

					<div class="atc-savings">
						<p>SAVE <br>$336</p>
					</div>

					<img class="atc-guarantee img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-guarantee.png" alt="">
					<img class="atc-img img-fluid" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-6.png" alt="">
				</div>

				<div class="atc-section" id="atc-right">
					<h6 class="text-white d-md-none mb-0" style="font-weight: 600;">6-MONTH SUPPLY</h6>
					<h1 class="atc-price mr-1 mb-0 mb-md-2"><span class="atc-dollar">$</span>33</h1><h5 class="mb-0 mb-md-2"> /EACH</h5>
					<p class="atc-whitetext d-none d-md-block">FAST & FREE SHIPPING</p>
					<p class="atc-yellowtext d-md-none">YOU SAVE $336</p>
					<p class="atc-whitetext mb-1 mb-md-3">365-DAY MONEY-BACK GUARANTEE</p>

					<div class="atc-button  mx-auto text-center">
						<h2 style="animation: none; opacity: 1; visibility: visible; transform: none;">DETOX NOW</h2><img class="img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-icon.svg" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-11 col-md-4 text-center py-0 px-md-1 px-lg-2">
		<div onclick="javascript:submitform('form_cta3');" class="atc-transform" style="cursor:pointer;">
			<img class="img-fluid shipping-ribbon d-md-none" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-shippingribbon.png" alt="">
			<div class="text-right text-md-left  div-71">
				<p class="text-blue atc-tab new-size">MOST POPULAR!</p>
			</div>
			
			<div class="atc">
				<div class="atc-section position-relative" id="atc-left">
					<h4 class="text-white d-none d-md-block">3-MONTH SUPPLY</h4>

					<div class="atc-savings">
						<p>SAVE <br>$120</p>
					</div>

					<img class="atc-guarantee img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-guarantee.png" alt="">
					<img class="atc-img img-fluid" src="https://cdn.truegcloud.com/xitox/bottle_graphics/Xitox-Box-500px-3%20%28v3%29.png" alt="">
				</div>

				<div class="atc-section" id="atc-right">
					<h6 class="text-white d-md-none mb-0" style="font-weight: 600;">4-MONTH SUPPLY</h6>
					<h1 class="atc-price mr-1 mb-0 mb-md-2"><span class="atc-dollar">$</span>49</h1><h5 class="mb-0 mb-md-2"> /EACH</h5>
					<p class="atc-whitetext d-none d-md-block">FAST & FREE SHIPPING</p>
					<p class="atc-yellowtext d-md-none">YOU SAVE $</p>
					<p class="atc-whitetext mb-1 mb-md-3">365-DAY MONEY-BACK GUARANTEE</p>

					<div class="atc-button mx-auto text-center">
						<h2 style="animation: none; opacity: 1; visibility: visible; transform: none;">DETOX NOW</h2><img class="img-fluid" src="https://cdn.truegcloud.com/xanoburn/images/atc/atc-icon.svg" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--<div class="row mbg-banner">
	<div class="col-lg-11 mx-auto">
		<img src="https://cdn.truegcloud.com/citroburn/images/MBG-Desktop.png" alt="" class="img-fluid my-2 d-none d-sm-block mx-auto">
		<center><img src="https://cdn.truegcloud.com/citroburn/images/MBG-Desktop.png" alt="" class="img-fluid my-2 d-block d-sm-none"></center>
	</div>
</div>-->

<script type="text/javascript">
	function submitform(formid) {
		window.onbeforeunload = function() {};
		//$('#' + formid).submit();
		document.getElementById(formid).submit();
	}
</script>

<style>
	.atc p, .atc-tab {
	font-family: 'montserrat';
}

.atc-tab {
	display: inline-block;
    background: #fbc630;
    padding: 11px 23px;
    border-radius: 15px 15px 0 0;
    font-weight: bold;
	margin: 0;
	line-height: 1;
}

.atc {
	background: url('https://cdn.truegcloud.com/xanoburn/images/atc/atc-bg.jpg');
	background-size: cover;
	background-position: center;
	padding: 25px 15px;
	position: relative;
	border: 4px solid transparent;
	display: flex;
	flex-direction: column;
}

.atc.center {
	border: 4px solid #fbc630;
	border-radius: 0px 4px 4px 4px;
}

.atc-img {
	max-height: 250px;
}

.atc-savings {
	background: #f3bc00;
    display: flex;
	align-items: center;
	justify-content: center;
    position: absolute;
    padding: 10px;
    border-radius: 50%;
    width: 100px;
    height: 100px;

	top: 25%;
    left: 95%;
    transform: translate(-95%, -25%) rotate(15deg);
}

.atc-guarantee {
	display: none;
	position: absolute;
	width: 50px;
    top: 95%;
    left: 90%;
    transform: translate(-90%, -95%);
}

.atc-savings p {
	font-weight: 800;
    font-size: 29px;
    line-height: 1em;
    color: #0a3b6c;
	margin: 0;
}

.atc-dollar {
    font-size: 30px;
    vertical-align: top;
    top: 12px;
    position: relative;
	margin-right: 3px;
}

.atc h5 {
	color: white;
    font-weight: bold;
    display: inline-block;
    letter-spacing: 1px;
}

.atc-whitetext {
	font-weight: bold;
    color: white;
    letter-spacing: -0.5px;
    font-size: 16px;
    font-family: 'Roboto', 'Helvetica' !important;
	margin: 0;
	line-height: 1.3;
}

.atc-yellowtext {
	font-weight: 900;
    color: #edba14;
    font-size: 12px;
    margin-bottom: 2px;
}

.atc-price {
	display: inline-block;
    font-size: 77px;
    color: #edba14;
}

.atc-button {
	background: #f3bc00;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px 0;
    margin: 0 8px;
}

.atc-button h2 {
	font-size: 19px;
    font-weight: 700;
    letter-spacing: 1px;
    margin: 0;
	padding-right: 10px;
	max-width: 90%;
    display: inline-block;
}

.atc-button img {
	max-width: 24px !important;
}

.desktop-width {
	margin-right: -50px !important; 
	margin-left: -50px !important;
}

/* Disable any scroll-triggered animations within the CTA button only */
.fe-atc-zindex .atc-button,
.fe-atc-zindex .atc-button * {
	animation: none !important;
	opacity: 1 !important;
	visibility: visible !important;
}

@media (max-width: 992px) {
	.atc-tab {
		padding: 8px 14px;
		font-size: 16px;
	}
	.atc-dollar {
		font-size: 20px;
		top: 7px;
	}
}

/*IPAD ONLY*/
@media (min-width: 768px) and (max-width: 992px) {
	.atc {
		padding: 15px 5px;
	}

	.atc-img {
		max-height: 200px;
	}

	.atc-savings {
		width: 80px;
		height: 80px;
	}

	.atc-savings p {
		font-size: 22px;
	}

	.atc-price {
		font-size: 45px;
	}

	.atc h5 {
		font-size: 15px;
	}

	.atc-whitetext {
		font-size: 12px;
	}

	.atc-button {
		padding: 10px 0;
	}

	.atc-button h2 {
		font-size: 15px;
	}
}

/*IPHONE ONLY*/
@media (max-width: 767px) {
	.atc {
		border: 2px solid #fbc630 !important;
		flex-direction: row;
		padding: 10px 5px;

		background-color: #153d65;
		background-position: 0px;
		background-size: 45%;
		background-repeat: no-repeat;
	}

	.atc-section {
		width: 50%;
		position: relative;
	}

	.atc-tab {
		padding: 5px 14px;
		font-size: 11px;
		border-radius: 8px 8px 0 0;
	}
	
	.atc-savings {
		display: none;
	}

	.atc-guarantee {
		display: block;
	}

	.atc-dollar {
		font-size: 17px;
		bottom: 16px;
    	margin-right: 2px;
		position: relative;
	}

	.atc h5 {
		font-size: 13px;
	}

	.atc-price {
		font-size: 40px;
	}

	.atc-button h2 {
		font-size: 12px;
		letter-spacing: 0;
	}

	.atc-button img {
		max-width: 15px !important;
	}

	.atc-button {
		padding: 10px 0;
		width: 80%;
    	margin: auto;
	}

	.atc-whitetext {
		font-size: 8.5px;
	}

	#atc-left {
		width: 45%;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	#atc-right {
		width: 55%;
		border-left: 2px solid;
   	 	border-image: linear-gradient( to top, transparent, #ffffff3d, transparent ) 1 100%;
	}

	.atc-img {
		max-height: 150px;
	}

	.shipping-ribbon {
		position: absolute;
		z-index: 2;
		width: 25%;
		left: -5%;
		top: 16%;
		transform: translate(5%, -16%);
	}
}
</style>  
                     </div>
                  </section>

               </div>
            </div>
         </section>
      </div>

      <style>
	@media (max-width: 991px) {
		#main-footer {
			margin-top: 0;
		}
		#main-footer .container {
			max-width: 100%;
			width: 100%;
			padding-right: 15px;
			padding-left: 15px;
			margin-right: auto;
			margin-left: auto;
			display: block;
			-ms-flex-wrap: unset;
	    	flex-wrap: unset;
			-webkit-box-pack: unset;
			-ms-flex-pack: unset;
			justify-content: unset;
		}
		#main-footer .container .row {
			max-width: 100%;
			margin: o auto;
			display: unset;
		}
		#main-footer .address, 
		#main-footer .phone, 
		#main-footer .mail {
			display: flex;
			text-align: left;
			width: 100%;
		}
	}
</style>

<footer id="main-footer" class="text-white py-5">
	<div class="container">
		<div class="row">
			<div class="col-lg-2">
				<img src="https://cdn.truegcloud.com/nutonen/footer-logo.png" alt="" class="img-fluid mb-4">
			</div>
			<div class="col-lg-4 order-lg-2">
				<h6 class="mb-3">Contact Information</h6>
				<div class="row">
					<div class="col-12">
						<p class="address"><img src="https://cdn.truegcloud.com/nutonen/icon-location1.svg" alt="" class="mr-2 d-lg-none" width="20"> 3242 NE 3rd Avenue #1051 Camas, WA 98607</p>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<p class="phone"><img src="https://cdn.truegcloud.com/nutonen/icon-phone1.svg" alt="" class="mr-2 d-lg-none" width="25"> 1-800-259-9522</p>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<p class="mail"><img src="https://cdn.truegcloud.com/nutonen/icon-mail1.svg" alt="" class="mr-2 d-lg-none" width="28"> Click <a href="http://help.simplepromise.com/support/tickets/new" class="text-yellow">here</a> to submit a ticket</p>
					</div>
				</div>
			</div>
			<div class="col-lg-6 order-lg-1">
				<h6>Disclaimer</h6>
				<p style="text-indent: 0px !important;">* These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease. Please Note: The material on this site is provided for informational purposes only and is not medical advice. Always consult your physician before beginning any diet or exercise program.</p>
				<p style="text-indent: 0px !important;">† Testimonials within our advertisement are real life reactions of real customer at Simple Promise™; however their name has been changed for privacy. Individual results may vary.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<ul>
					<li><a href="https://simplepromise.com/pages/privacy-policies">Privacy</a></li>
					<li><a href="https://simplepromise.com/pages/terms-disclaimer">Terms & Disclaimer</a></li>
					<li><a href="http://affiliates.truegenics.com/?site=Xitox">Affiliate Program</a></li>
				</ul>
			</div>
			<div class="col-md-12">
				<p class="text-center text-uppercase mb-0">Copyright &copy; 2019 &#8211; 2025 SIMPLE PROMISE&#8482;. ALL RIGHTS RESERVED.</p>
			</div>
		</div>
	</div>
</footer>

<!-- DO NOT DELETE THIS SCRIPTS -->
<script src="../js/jquery.min.js"></script>
<script src="../js/skeleton.bundle.min.js"></script>
<script src="../js/slidereveal.js"></script>
<script>
	$(function() {
		var slider = $("#menu-bar").slideReveal({
			// width: 100,
			push: false,
			position: "right",
			// speed: 600,
			trigger: $(".handle"),
			// autoEscape: false,
		});
	});
</script>
<!-- Additional Javascripts Goes Here -->      
      <script src="../js/slick.min.js"></script>
      <script src="../js/animation.js"></script>
   </body>
</html>